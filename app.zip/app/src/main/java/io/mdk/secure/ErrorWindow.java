package io.mdk.secure;

import android.app.AlertDialog;
import android.content.Context;
import android.telecom.Call;

import com.mohithulse.medikinesis.Home;
import com.mohithulse.medikinesis.R;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Created by Karthik on 17-10-2017.
 */

public class ErrorWindow {

    public static AlertDialog.Builder showError(String details, Throwable throwable, Context ctx){
        Home.cont = false; // Don't continue to any other window
        StringWriter stringWriter = new StringWriter();
        PrintWriter printstream = new PrintWriter(stringWriter);
        throwable.printStackTrace(printstream);
        String stackTrace = stringWriter.toString();
        printstream.close();
        try {
            stringWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle(R.string.err_pop_title);
        StringBuilder sb = new StringBuilder();
        sb.append(ctx.getString(R.string.err_def_disp));
        sb.append(System.lineSeparator());
        sb.append(details);
        sb.append(System.lineSeparator());
        sb.append(stackTrace);
        builder.setMessage(sb.toString());
        return builder;
    }

}
