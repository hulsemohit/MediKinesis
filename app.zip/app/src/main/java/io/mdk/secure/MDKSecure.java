package io.mdk.secure;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import org.jasypt.digest.StandardStringDigester;
import org.jasypt.salt.RandomSaltGenerator;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by Nikhil on 17-10-2017.
 */

public class MDKSecure {

    boolean firstrun;
    SharedPreferences prefs;

    private String DEV_ID;
    private String SPEC_ID;

    static final String TAG = "mdks";

    public void setSPEC_ID(String SPEC_ID) {
        this.SPEC_ID = SPEC_ID;
        prefs.edit().putString("spec-id",SPEC_ID).commit();
    }

    public void setDEV_ID(String DEV_ID) {
        this.DEV_ID = DEV_ID;
        prefs.edit().putString("dev-id",DEV_ID).commit();

    }

    private static MDKSecure instance;

    public synchronized static MDKSecure getInstance(Context context){
        if(instance == null){
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
            if(preferences.getBoolean("firstrun", true)){
                instance = new MDKSecure(true, context, preferences);
            } else {
                instance = new MDKSecure(false, context, preferences);
            }
        }
        return instance;
    }

    public synchronized static MDKSecure getInstance(){
        return instance;
    }

    protected MDKSecure(boolean firstrun, Context context, SharedPreferences prefs) {
        this.firstrun = firstrun;
        this.prefs = prefs;
        if(firstrun){
            Log.d(TAG, "MDKSecure: Creating firstboot configuration");
            SharedPreferences.Editor edit = prefs.edit();
            String uuid = UUID.randomUUID().toString();
            DEV_ID = "DEV"+uuid;
            SPEC_ID = "SPC"+Hash.generateSpecialID();
            edit.putString("dev-id", DEV_ID);
            edit.putString("spec-id", SPEC_ID);
            edit.putBoolean("firstrun", false);
            edit.apply();
        } else {
            Log.d(TAG, "MDKSecure: Found configuration");
            DEV_ID = prefs.getString("dev-id", null);
            SPEC_ID = prefs.getString("spec-id", null);
            Log.d(TAG, "MDKSecure: Loaded :"+ DEV_ID + ", " + SPEC_ID);
        }
    }

    public String getDevice_ID() {
        return DEV_ID;
    }

    public String getSpecial_ID() {
        return SPEC_ID;
    }

    public static class Hash {

        static StandardStringDigester digester;
        static final int MULT = 95;
        static final Random rand = new SecureRandom();

        static {
            digester = new StandardStringDigester();
            digester.setAlgorithm("SHA-256");
            digester.setSaltGenerator(new RandomSaltGenerator());
        }

        public static String hash_str(String input){
            return digester.digest(input);
        }

        public synchronized static String generateSpecialID(){
            String date = new SimpleDateFormat("HH:mm:ss:dd:MM:yyyy").format(new Date());
            String[] toki = date.split(":");
            int[] ints = new int[toki.length];
            for(int x=0; x<toki.length; x++){
                int INT = Integer.parseInt(toki[x]);
                ints[x] = INT;
            }
            StringBuilder sb = new StringBuilder();
            for (int x = 0; x < ints.length; x++) {
                sb.append("-");
                int INT = ints[x];
                if(x == (ints.length - 1)){
                    sb.append(Integer.toHexString(INT*getRandom(50, 250)));
                } else {
                    sb.append(Integer.toHexString(INT*MULT));
                }
            }
            return sb.toString();
        }

        public synchronized static boolean cmp(String input, String hash){
            return digester.matches(input, hash);
        }

        private static int getRandom(int min, int max){
            return rand.nextInt((max - min) + 1) + min;
        }

    }
    /*public void applyChanges(){
        prefs.apply();
    }*/
}
