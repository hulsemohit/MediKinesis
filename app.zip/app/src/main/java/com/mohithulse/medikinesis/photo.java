package com.mohithulse.medikinesis;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class photo extends Fragment {
    private static final int CAMERA_REQUEST = 1888;
    int photocount = 0;
    private ImageView imageView1;
    private ImageView imageView2;
    Globals g = Globals.getInstance();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.photo, container, false);
        imageView1 = (ImageView) view.findViewById(R.id.photo_taken);
        imageView2 = (ImageView) view.findViewById(R.id.photo_taken_2);

        byte[] byteArray = g.getImg1();
        Bitmap bitmap;
        if (byteArray != null) {
            photocount=1;
            bitmap = BitmapFactory.decodeByteArray(byteArray, 0,
                    byteArray.length);
            imageView1.setImageBitmap(bitmap);
        }

        byteArray = g.getImg2();
        if (byteArray != null) {
            photocount=2;

            bitmap = BitmapFactory.decodeByteArray(byteArray, 0,
                    byteArray.length);
            imageView2.setImageBitmap(bitmap);
        }






        FloatingActionButton camera = (FloatingActionButton)view.findViewById(R.id.Camera);
        camera.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(photocount<2) {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }else{
                    Toast.makeText(getContext(),"Maximum Images Reached!",Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {

                Bitmap bmp = (Bitmap) data.getExtras().get("data");
                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                // convert byte array to Bitmap

                Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0,
                        byteArray.length);

                switch (photocount){
                    case 0:
                        imageView1.setImageBitmap(bitmap);
                        g.setImg1(byteArray);

                        break;
                    case 1:
                        imageView2.setImageBitmap(bitmap);
                        g.setImg2(byteArray);
                        break;

                    default:
                        Toast.makeText(getContext(),"Maximum Images Reached", Toast.LENGTH_SHORT).show();
                        break;
                }
                photocount++;

            }
        }
    }
}

