package com.mohithulse.medikinesis;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class Hospitals extends AppCompatActivity {

    TextView t1;
    EditText et1;
    FloatingActionButton f1;
    Globals g = Globals.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        g.global_store.put("cur.act.ctx",  this.getApplicationContext());
        setContentView(R.layout.activity_hospitals);
        g.setServer((String)g.global_store.get("server.id"));
        t1 = (TextView)findViewById(R.id.report);

        f1= (FloatingActionButton)findViewById(R.id.getReport);
        et1 =(EditText)findViewById(R.id.editTextName);

        f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BackgroundTasks.ClientNoteView clientNoteView = new BackgroundTasks.ClientNoteView((et1.getText().toString()+".rp"),t1);
                clientNoteView.execute();
            }
        });



    }
}
