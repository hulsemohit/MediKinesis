package com.mohithulse.medikinesis;

import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.CalendarContract;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Timer;


public class symptoms extends Fragment {

    String[] symptoms = {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59",
            "60",
            "61",
            "62",
            "63",
            "63",
            "65",
            "66",
            "67",
            "68",
            "69",
            "70",
            "71",
            "72",
            "73",
            "74",
            "75",
            "76",
            "77",
            "78",
            "79",
            "80",
            "81",
            "82",
            "83",
            "84",
            "85",
            "86",
            "87",
            "88",
            "89",
            "90",
            "91",
            "92",
            "93",
            "94",
            "95",
            "96",
            "97",
            "98",
            "99",
            "100",
            "101",
            "102",
            "103",
            "104",
            "105",
            "106",
            "107",
            "108",
            "109",
            "110",
            "111",


    };


    boolean[] selected = new boolean[symptoms.length];

    boolean[] pulmonologist = new boolean[symptoms.length];
    boolean[] ENT = new boolean[symptoms.length];
    boolean[] Cardiologist = new boolean[symptoms.length];
    boolean[] Gastroenterologist = new boolean[symptoms.length];
    boolean[] GeneralSurgeon = new boolean[symptoms.length];
    boolean[] Neurosurgeon = new boolean[symptoms.length];
    boolean[] Neurologist = new boolean[symptoms.length];
    boolean[] Nephrologist = new boolean[symptoms.length];
    boolean[] Dermatologist = new boolean[symptoms.length];
    boolean[] Neonatologist = new boolean[symptoms.length];
    boolean[] Endocrinologist = new boolean[symptoms.length];
    boolean[] HeamatoOncologist = new boolean[symptoms.length];
    boolean[] Urologist = new boolean[symptoms.length];
    boolean[] psychiatrist= new boolean[symptoms.length];
    boolean[] Orthopaedician = new boolean[symptoms.length];
    boolean[] Ophthalmologist = new boolean[symptoms.length];
    boolean[] Gynaecologist = new boolean[symptoms.length];
    boolean[] Emergency = new boolean[symptoms.length];

    String SpecialistName[]={"pulmonologist", "ENT", "Cardiologist", "Gastroenterologist", "General Surgeon", "Neurosurgeon",
            "Nephrologist", "Dermatologist", "Neonatologist", "Endocrinologist", "Heamato-oncologist", "Urologist", "Psychiatrist",
            "Orthopaedician", "Ophthalmologist", "Gynaecologist", "Hospital Emergency department" };
    ArrayList<String> finalSymptoms = new ArrayList<>();

    ListView list;

    Globals g= Globals.getInstance();



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.symptoms, container, false);
        list=(ListView) view.findViewById(R.id.SymptomsList);
        ListAdapter itemsAdapter = new ListAdapter(getContext(), android.R.layout.simple_list_item_1, symptoms);
        list.setAdapter(itemsAdapter);



        //pulmonologist
        pulmonologist[7]= true;
        pulmonologist[14] = true;
        pulmonologist[17] = true;
        pulmonologist[23] = true;
        pulmonologist[25] = true;
        pulmonologist[76] = true;
        pulmonologist[82] = true;
        pulmonologist[102] = true;

        //ENT
        ENT[10] = true;
        ENT[30] = true;
        ENT[35] = true;
        ENT[36] = true;
        ENT[76] = true;

        //Cardiologist
        Cardiologist[16] = true;
        Cardiologist[21] = true;
        Cardiologist[49] = true;
        Cardiologist[53] = true;
        Cardiologist[66] = true;
        Cardiologist[86] = true;
        Cardiologist[97] = true;
        Cardiologist[103] = true;

        //Gastroenterologist
        Gastroenterologist[2] = true;
        Gastroenterologist[3] = true;
        Gastroenterologist[9] = true;
        Gastroenterologist[12] = true;
        Gastroenterologist[45] = true;
        Gastroenterologist[33] = true;
        Gastroenterologist[46] = true;
        Gastroenterologist[48] = true;
        Gastroenterologist[54] = true;
        Gastroenterologist[58] = true;

        //General Surgeon
        GeneralSurgeon[1] = true;
        GeneralSurgeon[3] = true;
        GeneralSurgeon[5] = true;
        GeneralSurgeon[9] = true;
        GeneralSurgeon[44] = true;
        GeneralSurgeon[72] = true;

        //NeuroSurgeon
        Neurosurgeon[15] = true;
        Neurosurgeon[92] = true;

        //Neurologist
        Neurologist[0] = true;
        Neurologist[15] = true;
        Neurologist[24] = true;
        Neurologist[27] = true;
        Neurologist[31] = true;
        Neurologist[42] = true;
        Neurologist[51] = true;
        Neurologist[73] = true;
        Neurologist[74] = true;
        Neurologist[79] = true;
        Neurologist[101] = true;

        //Nephrologist
        Nephrologist[18] = true;
        Nephrologist[47] = true;
        Nephrologist[64] = true;
        Nephrologist[65] = true;
        Nephrologist[100]=true;

        //Dermatologist
        Dermatologist[34]=true;
        Dermatologist[50]=true;
        Dermatologist[81]=true;
        Dermatologist[84]=true;
        Dermatologist[87]=true;
        Dermatologist[90]=true;
        Dermatologist[91]=true;

        //Neonatologist
        Neonatologist[77]=true;

        //Endocrinologist
        Endocrinologist[22]=true;
        Endocrinologist[28]=true;
        Endocrinologist[56]=true;
        Endocrinologist[57]=true;
        Endocrinologist[67]=true;
        Endocrinologist[70]=true;
        Endocrinologist[80]=true;
        Endocrinologist[85]=true;
        Endocrinologist[89]=true;
        Endocrinologist[98]=true;
        Endocrinologist[107]=true;
        Endocrinologist[108]=true;

        //Heamato-oncologist
        HeamatoOncologist[11] = true;
        HeamatoOncologist[13] = true;
        HeamatoOncologist[69] = true;
        HeamatoOncologist[71] = true;

        //Urologist
        Urologist[65] =true;

        //Psychiatrist
        psychiatrist[4] = true;
        psychiatrist[37] = true;
        psychiatrist[40] = true;
        psychiatrist[75] = true;
        psychiatrist[78] = true;
        psychiatrist[110] = true;


        //Orthopaedician
        Orthopaedician[6] = true;
        Orthopaedician[8] = true;
        Orthopaedician[31] = true;
        Orthopaedician[61] = true;
        Orthopaedician[62] = true;
        Orthopaedician[63] = true;
        Orthopaedician[92] = true;

        //Ophthalmologist
        Ophthalmologist[20] = true;
        Ophthalmologist[32] = true;
        Ophthalmologist[38] = true;
        Ophthalmologist[60] = true;
        Ophthalmologist[94] = true;
        Ophthalmologist[105] = true;

        //Gynaecologist
        Gynaecologist[52] = true;
        Gynaecologist[57] = true;
        Gynaecologist[80] = true;
        Gynaecologist[83] = true;

        //Emergency
        Emergency[5] = true;
        Emergency[10] = true;
        Emergency[19] = true;
        Emergency[39] = true;
        Emergency[55] = true;
        Emergency[79] = true;
        Emergency[95] = true;
        Emergency[96] = true;
        Emergency[99] = true;
        Emergency[100] = true;

        Specialist Pulmonologist = new Specialist(pulmonologist, "Pulmonologist");
        Specialist ent = new Specialist(ENT, "ENT");
        Specialist cardiologist = new Specialist(Cardiologist, "Cardiologist");
        Specialist gastroenterologist = new Specialist(Gastroenterologist, "Gastroenterologist");
        Specialist Generalsurgeon = new Specialist(GeneralSurgeon, "General Surgeon");
        Specialist NeuroSurgeon = new Specialist(Neurosurgeon, "Neurosurgeon");
        Specialist neurologist = new Specialist(Neurologist, "Neurologist");
        Specialist nephrologist = new Specialist(Nephrologist, "Nephrologist");
        Specialist dermatologist = new Specialist(Dermatologist, "Dermatologist");
        Specialist neonatologist = new Specialist(Neonatologist, "Neonatologist");
        Specialist endocrinologist = new Specialist(Endocrinologist, "Endocrinologist");
        Specialist haematooncologist = new Specialist(HeamatoOncologist, "Haemato-Oncologist");
        Specialist urologist = new Specialist(Urologist, "Dermatologist");
        Specialist Psychiatrist = new Specialist(psychiatrist, "Psychiatrist");
        Specialist orthopaedician = new Specialist(Orthopaedician, "Orthopaedician");
        Specialist ophthalmologist = new Specialist(Ophthalmologist, "Opthalmologist");
        Specialist gynaecologist = new Specialist(Gynaecologist, "Gynaecologist");
        Specialist emergency = new Specialist(Emergency, "Emergency");

        Specialist[] all ={
                Pulmonologist,
                ent,
                cardiologist,
                gastroenterologist,
                Generalsurgeon,
                NeuroSurgeon,
                neurologist,
                nephrologist,
                dermatologist,
                neonatologist,
                endocrinologist,
                haematooncologist,
                urologist,
                Psychiatrist,
                orthopaedician,
                ophthalmologist,
                gynaecologist,
                emergency
        };


        g.setTotal(all);




        if(g.getChecked()!=null){
            selected = g.getChecked();
        }






        list.setOnItemClickListener ( new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selected[position] = !selected[position];
                if(selected[position]) {
                    finalSymptoms.add(symptoms[position]);
                }else{
                    if(finalSymptoms.contains(symptoms[position]))
                    finalSymptoms.remove(symptoms[position]);
                }
                g.setSymptoms(finalSymptoms);
                g.setChecked(selected);

                if(selected[position]) {
                    view.setBackgroundColor(Color.parseColor("#ff00ddff"));
                }else{
                    view.setBackgroundColor(Color.parseColor("#00000000"));
                }

            }});

        refresh.start();
        return view;
    }
    CountDownTimer refresh = new CountDownTimer(1,1000) {
        @Override
        public void onTick(long millisUntilFinished) {

            Toast.makeText(getContext(),"updated", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onFinish() {
            refresh.start();

        }
    };

}
