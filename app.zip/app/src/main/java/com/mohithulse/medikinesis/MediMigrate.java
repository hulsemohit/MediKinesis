package com.mohithulse.medikinesis;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.StrictMode;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.net.InetAddress;
import java.net.UnknownHostException;

import io.mdk.secure.MDKSecure;
import io.mdk.transfer.Server;

public class MediMigrate extends AppCompatActivity implements View.OnClickListener {

    Button to;
    Button from;
    ImageButton info;

    EditText e;
    Button s;

    String Dname ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medi_migrate);
        to = (Button)findViewById(R.id.MigrateTo);
        from = (Button)findViewById(R.id.MigrateFrom);
        info =(ImageButton)findViewById(R.id.Migrateinfo);
        e=(EditText)findViewById(R.id.MigrateDeviceName);
        s=(Button)findViewById(R.id.SubmitMigrateDeviceName);

        to.setOnClickListener(this);
        from.setOnClickListener(this);
        info.setOnClickListener(this);



    }

    public AlertDialog display(String string, Context context, final Runnable onClick){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle("Migrate");
        alertDialog.setMessage(string);
        alertDialog.setNeutralButton("Okay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onClick.run();
            }
        });
        return alertDialog.create();

    }


    @Override
    public void onClick(View v) {
        if(v==to){


            display("Please make sure both devices are connected to a common network...", MediMigrate.this, new Runnable() {
                @Override
                public void run() {
                    Log.d("Config", "run: "+MDKSecure.getInstance().getDevice_ID());
                    Server server = new  Server(7878, MDKSecure.getInstance().getDevice_ID(), MDKSecure.getInstance().getSpecial_ID());
                    server.start();
                    try {
                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        StrictMode.setThreadPolicy(policy);
                        InetAddress local = InetAddress.getLocalHost();
                        String ip = local.getHostAddress()+" or "+local.getHostName();
                        Snackbar.make(to,"Enter this in the other device: "+ip, Snackbar.LENGTH_INDEFINITE).show();
                    } catch (UnknownHostException e1) {
                        e1.printStackTrace();
                    }


                }
            }).show();
        }
        if(v==from){
            e.setVisibility(View.VISIBLE);
           s.setVisibility(View.VISIBLE);
            s.setOnClickListener(new View.OnClickListener() {
              @Override
                public void onClick(View v) {
                  e.setVisibility(View.GONE);
                   e.setVisibility(View.GONE);
                  Dname = e.getText().toString();
                    display("Please make sure both devices are connected to a common network...", MediMigrate.this, new Runnable() {
                        @Override
                        public void run() {
                            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                            StrictMode.setThreadPolicy(policy);
                            io.mdk.transfer.Client cli = new io.mdk.transfer.Client(Dname,7878);
                            cli.bridge();
                            String [] id= cli.handle();
                            MDKSecure.getInstance().setDEV_ID(id[0]);
                            MDKSecure.getInstance().setSPEC_ID(id[1]);
                        }
                    }).show();
                }
            });

        }
        if(v==info){
            Intent i = new Intent(this, MigrateInfo.class);
            startActivity(i);
        }



    }
}
