package com.mohithulse.medikinesis;


public class Specialist {
    private boolean[] symptoms;
    private String name;
    private int Score = 0;

    public Specialist(boolean[] symptoms, String name) {
        this.symptoms = symptoms;
        this.name = name;
    }

    public boolean[] symptoms() {
        return symptoms;
    }

    public String name(){
        return name;
    }

    public void setScore(int score) {
        Score = score;
    }

    public int score(){
        return Score;
    }
}
