package com.mohithulse.medikinesis;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MigrateInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_migrate_info);
    }
}
