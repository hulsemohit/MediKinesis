package com.mohithulse.medikinesis;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArraySet;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Set;

public class YourInfos extends AppCompatActivity implements View.OnClickListener {

    FloatingActionButton capture;
    RecyclerView recyclerView;
    ArrayList<String> images = new ArrayList<>() ;
    int CAMERA_REQUEST = 1888;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_infos);
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        capture = (FloatingActionButton)findViewById(R.id.ImageCaptureForInfo);
        capture.setOnClickListener(this);

        SharedPreferences s = PreferenceManager.getDefaultSharedPreferences(this);
        Intent a= getIntent();
        if(a.getIntExtra("type", R.id.Expenses)==R.id.Expenses){
            for(int i= 0; i<s.getInt("lengtha",0);i++){
                images.add(s.getString(String.valueOf(i)+"a", " "));
            }
        }else{
            for(int i= 0; i<s.getInt("lengthb",0);i++){
                images.add(s.getString(String.valueOf(i)+"b", " "));
            }
        }


        if(images==null) {
            images = new ArrayList<>();
        }
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setLayoutManager(layoutManager);
        MyAdapter adapter = new MyAdapter(getApplicationContext(), images );
        recyclerView.setAdapter(adapter);







    }

    @Override
    public void onClick(View v) {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST);



    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            photo.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] byteArray = baos.toByteArray();
            String encodedImage = Base64.encodeToString(byteArray, Base64.NO_WRAP);

            images.add(encodedImage);

            MyAdapter adapter = new MyAdapter(getApplicationContext(), images );
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(YourInfos.this);
        SharedPreferences.Editor editor = sp.edit();

        Intent i = getIntent();
        if(i.getIntExtra("type",R.id.Expenses)==R.id.Expenses) {
            editor.putInt("lengtha", images.size());
            for(int a =0; a<images.size();a++){
                editor.putString(String.valueOf(a)+"a",images.get(a));
            }
        }else{
            editor.putInt("lengthb", images.size());
            for(int a =0; a<images.size();a++){
                editor.putString(String.valueOf(a)+"b",images.get(a));
            }
        }

        editor.apply();
    }
}
