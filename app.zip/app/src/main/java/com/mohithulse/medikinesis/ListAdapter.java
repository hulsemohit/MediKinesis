package com.mohithulse.medikinesis;


import android.content.Context;
import android.widget.ArrayAdapter;


public class ListAdapter extends ArrayAdapter {


    public ListAdapter(Context context, int resource, Object[] objects) {
        super(context, resource, objects);
    }




}
   /* private Context context;
    private String[] items;
    private int lastPosition = 0;
    Globals g = Globals.getInstance();

    public ListAdapter(Context context, String[] items) {
        super();
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return this.items.length;
    }

    @Override
    public Object getItem(int position) {
        return this.items[position];
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        if (null == convertView) {
            parent =  LinearLayout.inflate(this.context,
                    R.layout.symptoms, null);
            Log.d("SeenDroid", String.format("Get view %d", position));
            TextView title = new TextView(convertView.getContext());
            convertView.addView(title);
            if(g.getChecked()[position]) {
                title.setBackgroundColor(Color.parseColor("#ff00ddff"));
            }else{
                title.setBackgroundColor(Color.parseColor("#00000000"));
            }
            return view;
        } else {
            LinearLayout view = (LinearLayout) convertView;
            TextView title = (TextView) view.getChildAt(0);
            if(g.getChecked()[position]) {
                title.setBackgroundColor(Color.parseColor("#ff00ddff"));
            }else{
                title.setBackgroundColor(Color.parseColor("#00000000"));
            }
            return convertView;
        }
    }*/


