package com.mohithulse.medikinesis;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Home extends AppCompatActivity implements View.OnClickListener{
    ImageButton AskaDoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //findViewById's
        AskaDoc=(ImageButton)findViewById(R.id.AskDoc);

        //setOnClickListeners
        AskaDoc.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent I;
        if(v==AskaDoc){
            I=new Intent(Home.this,AskADoc.class);
            startActivity(I);

        }
    }
}
