package com.mohithulse.medikinesis;


import io.mdk.net.client.Client;
import io.mdk.secure.MDKSecure;

import java.util.ArrayList;
import java.util.HashMap;

public class Globals {
    private static final Globals instance = new Globals();

    private byte[] img1;
    private byte[] img2;
    private String pin;

    private static final String TAG = "global";

    private String name = "";
    private int Age = 0;
    private boolean male;
    private String address="";
    private String Server ="";
    private String Description=null;
    private ArrayList<String> Symptoms = new ArrayList<>();
    private Client client;
    private String[] list ={"",""};

    protected HashMap<String, Object>  global_store = new HashMap<>();
    protected MDKSecure secure;

    private boolean noted;

    public boolean isNoted() {
        return noted;
    }

    public void setNoted(boolean noted) {
        this.noted = noted;
    }

    public void setList(String[] list) {
        this.list = list;
    }

    public String[] getList() {
        return list;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPin() {
        return pin;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Client getClient() {

        return client;
    }

    public void setSymptoms(ArrayList<String> symptoms) {
        Symptoms = symptoms;
    }

    public ArrayList<String> getSymptoms() {
        return Symptoms;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public byte[] getImg2() {
        return img2;
    }

    public byte[] getImg1() {
        return img1;
    }

    public void setImg1(byte[] img1) {
        this.img1 = img1;
    }

    public void setImg2(byte[] img2) {
        this.img2 = img2;
    }

    public byte[][] getImages() {
        byte[][] images ={img1,img2};
        return images;
    }

    public void setServer(String server){
        Server = server;
        BackgroundTasks.ClientInit cli = new BackgroundTasks.ClientInit();
        cli.execute();
    }

    public String getServer() {

        return Server;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        Age = age;
    }

    public void setMale(boolean male) {
        this.male = male;
    }

    public String getName() {
        return name;
    }

    public boolean isMale() {
        return male;
    }

    public int getAge() {
        return Age;
    }


    public static Globals getInstance() {
        return instance;
    }
}
