package com.mohithulse.medikinesis;

import java.util.ArrayList;

public class Globals {

    private static Globals instance = new Globals();

    private byte[] img1 =null;
    private byte[] img2 =null;
    private byte[][] images = {img1,img2} ;

    private String Description = null;

    private ArrayList<String> symptoms = null;

    private boolean[] checked = null;

    private Specialist[] total;

    public void setTotal(Specialist[] total) {
        this.total = total;
    }

    public Specialist[] getTotal() {
        return total;
    }

    public void setChecked(boolean[] checked) {
        this.checked = checked;
    }

    public boolean[] getChecked() {
        return checked;
    }

    public void setSymptoms(ArrayList<String> symptoms) {this.symptoms = symptoms;}

    public ArrayList<String> getSymptoms() {return symptoms;}

    public byte[][] getImages() {return images;}

    public static Globals getInstance() {
         return instance;
     }

    public void setDescription(String description) {
        this.Description = description;
    }

    public void setImg1(byte[] img1) {
        this.img1 = img1;
    }

    public void setImg2(byte[] img2) {
        this.img2 = img2;
    }

    public String getDescription() {
        return this.Description;
    }

    public byte[] getImg1() {
        return this.img1;

    }

    public byte[] getImg2() {
        return this.img2;
    }

}
