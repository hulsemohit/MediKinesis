package com.mohithulse.medikinesis;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class description extends Fragment implements View.OnClickListener {
    ArrayList<String> finalSpecialists= new ArrayList<>();

    FloatingActionButton edit;
    EditText DescriptionBox;
    Globals g = Globals.getInstance();
    FloatingActionButton submit;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.description, container, false);
        edit=(FloatingActionButton)view.findViewById(R.id.editDescription);
        DescriptionBox =(EditText)view.findViewById(R.id.description);
        submit =(FloatingActionButton)view.findViewById(R.id.finalise);

        if(g.getDescription()!=null){
            DescriptionBox.setText(g.getDescription());
        }
        edit.setOnClickListener(this);
        submit.setOnClickListener(this);
        return view;



    }

    @Override
    public void onClick(View v) {
        if(v==edit) {
            g.setDescription(DescriptionBox.getText().toString());
            Toast.makeText(getContext(), "Description Saved!", Toast.LENGTH_SHORT).show();
        }
        if(v==submit){
            setSpecialist(g.getTotal());
            String text = "You can see a Physician/Paediatrician";
            for(int i =0; i<finalSpecialists.size(); i++){
               text = text + " or "+finalSpecialists.get(i);
            }
            Toast.makeText(getContext(),text,Toast.LENGTH_SHORT).show();

        }

    }

    public void setSpecialist(Specialist[] total){
        ArrayList<Integer> scores = new ArrayList<>();
        ArrayList<String> finalSpecialist =  new ArrayList<>();



        for(int i=0; i<total.length; i++){
            total[i].setScore(0);
            for(int a=0; a<total[i].symptoms().length;a++){

                if(total[i].symptoms()[a]&&g.getChecked()[a]){
                    total[i].setScore(total[i].score()+1);

                }

            }
            scores.add(total[i].score());

        }

        int max = Collections.max(scores);

        if(max>0) {
            for (int x = 0; x < total.length; x++) {
                if (total[x].score() == max) {
                    finalSpecialist.add(total[x].name());
                }

            }
            finalSpecialists = finalSpecialist;
        }


    }


}
