package com.mohithulse.medikinesis;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.Set;

public class YourDetails extends AppCompatActivity {
    EditText name;
    EditText Age;
    EditText Address;
    FloatingActionButton setdetailbtn;
    RadioGroup  Gender;
    boolean male = true;


    Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_details);
        name = (EditText)findViewById(R.id.editDetailName);
        Age = (EditText)findViewById(R.id.editDetailAge);
        Address = (EditText)findViewById(R.id.editDetailAddress);
        setdetailbtn = (FloatingActionButton)findViewById(R.id.setDetailsbtn);
        Gender = (RadioGroup)findViewById(R.id.DetailMaleFemale);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        name.setText(preferences.getString("Name", ""));
        male = preferences.getBoolean("Gender", true);
        if(male) {
            ((RadioButton)findViewById(R.id.RBmale)).setChecked(true);
            ((RadioButton)findViewById(R.id.RBfemale)).setChecked(false);

        }else{
            ((RadioButton)findViewById(R.id.RBmale)).setChecked(false);
            ((RadioButton)findViewById(R.id.RBfemale)).setChecked(true);
        }
        Address.setText(preferences.getString("Address", ""));
        Age.setText(String.valueOf(preferences.getInt("Age", 0)));


        Gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                male = (checkedId == R.id.RBmale);
            }
        });

        setdetailbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g.setAge(Integer.parseInt(Age.getText().toString()));
                g.setName(name.getText().toString());
                g.setMale(male);
                g.setAddress(Address.getText().toString());

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(YourDetails.this);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("Name",g.getName());
                editor.putInt("Age",g.getAge());
                editor.putString("Address",g.getAddress());
                editor.putBoolean("Gender", g.isMale());
                editor.apply();


            }

        });
    }
}