package com.mohithulse.medikinesis;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import io.mdk.secure.MDKSecure;


public class Home extends AppCompatActivity implements View.OnClickListener {


    ImageButton Askadoc;
    ImageButton Emergency;
    ImageButton YourMedikinesis;
    ImageButton Hospitals;
    ImageButton Doctor;
    ImageButton Specialists;
    public static Activity context;
    EditText ipField;

    Globals g = Globals.getInstance();

    public static boolean cont = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        g.secure = MDKSecure.getInstance(getApplicationContext());
        setContentView(R.layout.activity_home);
        Askadoc = (ImageButton)findViewById(R.id.AskDoc);
        Emergency = (ImageButton)findViewById(R.id.Emergency);
        YourMedikinesis = (ImageButton)findViewById(R.id.YourMedikinesis);
        Hospitals = (ImageButton)findViewById(R.id.Hospitals);
        Doctor = (ImageButton)findViewById(R.id.doctorpagebtn);
        Specialists = (ImageButton)findViewById(R.id.specialists);
        ipField=(EditText)findViewById(R.id.ServerAddressField);

        context= this;

        Askadoc.setOnClickListener(this);
        Emergency.setOnClickListener(this);
        YourMedikinesis.setOnClickListener(this);
        Hospitals.setOnClickListener(this);
        Doctor.setOnClickListener(this);
        Specialists.setOnClickListener(this);

        if((g.getClient()!=null)&&(!g.getClient().shutdown)) {
            BackgroundTasks.ClientClose clientClose = new BackgroundTasks.ClientClose();
            clientClose.execute();
        }

    }

    @Override
    public void onClick(View v) {
        g.global_store.put("server.id", ipField.getText().toString());
        if(v==Askadoc && cont){
            Intent i = new Intent(Home.this, AskADoc.class);
            startActivity(i);
        }
        if(v==Emergency && cont){
            Intent i = new Intent(Home.this, Emergency.class);
            startActivity(i);
        }
        if(v==YourMedikinesis && cont){
            Intent i = new Intent(Home.this, YourMedikinesis.class);
            startActivity(i);
        }
        if(v==Hospitals && cont){
            Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                    Uri.parse("google.navigation:q=Hospitals"));
            startActivity(intent);
        }if(v==Doctor && cont){
            Intent i = new Intent(Home.this, Pharmacies.class);
            startActivity(i);
        }if(v==Specialists && cont){
            Intent i = new Intent(Home.this, Specialists.class);
            startActivity(i);
        }
    }

}
