package com.mohithulse.medikinesis;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutionException;

import io.mdk.net.utils.Report;

import static android.content.ContentValues.TAG;

public class Pharmacies extends AppCompatActivity {
    EditText pin;
    Button btn;
    String[] patients ;
    ListView list;
    ImageView img1;
    ImageView img2;

    TextView symptoms;
    TextView namenagengender;
    TextView synopsis;

    EditText note;
    String user="";

    Report report;

    Globals g = Globals.getInstance();
    FloatingActionButton send;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        g.global_store.put("cur.act.ctx", Pharmacies.this);
        setContentView(R.layout.activity_pharmacies);
        g.setServer((String)g.global_store.get("server.id"));
        pin= (EditText)findViewById(R.id.pinfield);
        btn = (Button)findViewById(R.id.button);
        list  =(ListView)findViewById(R.id.patientsList);
        img1 =(ImageView)findViewById(R.id.sentimg1);
        img2 =(ImageView)findViewById(R.id.sentimg2);
        synopsis =(TextView)findViewById(R.id.DescriptionSent);
        symptoms = (TextView)findViewById(R.id.Symptomssent);
        send =(FloatingActionButton)findViewById(R.id.sendNote);
        note= (EditText)findViewById(R.id.AddNotes) ;
        send.setVisibility(View.GONE);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BackgroundTasks.ClientReportNote clientReportNote= new BackgroundTasks.ClientReportNote(note.getText().toString(),user, report);
                if(g.isNoted()) {
                    Snackbar.make(v,"This report has already been cleared!", Snackbar.LENGTH_LONG).show();
                }else{
                    Snackbar.make(v,"Sending...", Snackbar.LENGTH_LONG).show();
                    clientReportNote.execute();
                }
            }
        });

        namenagengender=(TextView)findViewById(R.id.AgenGender);

        note = (EditText)findViewById(R.id.AddNotes);
        img2 =(ImageView)findViewById(R.id.sentimg2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g.setPin(pin.getText().toString());
                Log.d("","Pin:" + g.getPin());
                pin.setVisibility(View.GONE);
                btn.setVisibility(View.GONE);

                BackgroundTasks.ClientReportList clientReportList = new BackgroundTasks.ClientReportList(getApplicationContext(),list);
                Log.d(TAG,"about to get list");
                clientReportList.execute();

                patients =g.getList();
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BackgroundTasks.ClientReportView clientReportView = new BackgroundTasks.ClientReportView(synopsis,namenagengender,symptoms,img2,img1, g.getList()[position]);
                Log.d(TAG, "onItemClick: "+ g.getList()[position]);
                user = g.getList()[position];
                Toast.makeText(getApplicationContext(), "Please Wait...", Toast.LENGTH_SHORT).show();
                try {
                    list.setVisibility(View.GONE);
                    send.setVisibility(View.VISIBLE);
                    clientReportView.execute().get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
                report = clientReportView.report;
            }
        });

    }
}
