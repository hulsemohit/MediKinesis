package io.mdk.secure;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Nikhil on 19-10-2017.
 */

public class NoteLocker {

    static final String regex = "(.*?)\\{((?:\\{[^\\{}]*\\}|.)*?)\\}(.*?);";
    static final Pattern pattern = Pattern.compile(regex);

    static final int DEV_GROUP = 1;
    static final int SPEC_GROUP = 3;
    static final int NOTE_GROUP = 2;

    public synchronized static String lock(String note, String dev, String spec) {
        return dev + "{" + note + "}" + spec + ";";
    }

    public synchronized static String unlock(String locked){
        Matcher matcher = pattern.matcher(locked);
        String devlock;
        String speclock;
        while(matcher.find()){
            devlock = matcher.group(1);
            speclock = matcher.group(3);
            String note = matcher.group(2);
            if(MDKSecure.Hash.cmp(MDKSecure.getInstance().getDevice_ID(), devlock) && MDKSecure.Hash.cmp(MDKSecure.getInstance().getSpecial_ID(), speclock)) {
                return note;
            } else {
                return "<h1>This is not your report, please do not try to view the reports of others</h1>";
            }
        }
        return null;
    }

}
