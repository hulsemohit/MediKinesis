package com.mohithulse.medikinesis;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class description extends Fragment implements View.OnClickListener {

    FloatingActionButton edit;
    EditText DescriptionBox;
    Globals g = Globals.getInstance();
    FloatingActionButton submit;
    EditText editName;
    EditText editAge;
    EditText editAddress;
    RadioGroup radioGroup;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.description, container, false);
        edit=(FloatingActionButton)view.findViewById(R.id.editDescription);
        DescriptionBox =(EditText)view.findViewById(R.id.description);
        submit =(FloatingActionButton)view.findViewById(R.id.finalise);
        editName = (EditText)view.findViewById(R.id.editName);
        editAge = (EditText)view.findViewById(R.id.editAge);
        editAddress=(EditText)view.findViewById(R.id.editAddress);
        radioGroup = (RadioGroup)view.findViewById(R.id.MaleFemale);
        g.setMale(true);
        if(g.getDescription()!=null){
            DescriptionBox.setText(g.getDescription());
        }


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        editName.setText(preferences.getString("Name", ""));
        editAge.setText(String.valueOf(preferences.getInt("Age",0)));
        editAddress.setText(preferences.getString("Address",""));

        if(preferences.getBoolean("Gender", true)){
            ((RadioButton)view.findViewById(R.id.male)).setChecked(true);
            ((RadioButton)view.findViewById(R.id.female)).setChecked(false);

        }else{
            ((RadioButton)view.findViewById(R.id.male)).setChecked(false);
            ((RadioButton)view.findViewById(R.id.female)).setChecked(true);
        }


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                g.setMale(checkedId==R.id.male);
            }
        });

        edit.setOnClickListener(this);
        submit.setOnClickListener(this);
        return view;




    }

    @Override
    public void onClick(View v) {
        if(v==edit) {
            g.setDescription(DescriptionBox.getText().toString());
            g.setName(editName.getText().toString());
            g.setAge(Integer.parseInt(editAge.getText().toString()));
            g.setAddress(editAddress.getText().toString());
            Toast.makeText(getContext(), "Description Saved!", Toast.LENGTH_SHORT).show();
        }
        if(v==submit){
            g.setDescription(DescriptionBox.getText().toString());
            g.setName(editName.getText().toString());
            g.setAge(Integer.parseInt(editAge.getText().toString()));
            g.setAddress(editAddress.getText().toString());
            String[] symptoms = new String[g.getSymptoms().size()];
            g.getSymptoms().toArray(symptoms);
            BackgroundTasks.ClientReport clientReport = new BackgroundTasks.ClientReport(g.getImages(),symptoms,g.getDescription(),g.isMale(),g.getAge(),submit);
            //Toast.makeText(getContext(), "Sending...", Toast.LENGTH_SHORT).show();
            clientReport.execute();

        }

    }

}
