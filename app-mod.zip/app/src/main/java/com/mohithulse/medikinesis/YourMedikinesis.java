package com.mohithulse.medikinesis;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class YourMedikinesis extends AppCompatActivity implements View.OnClickListener {
    ImageButton Details;
    ImageButton Expenses;
    ImageButton Prescriptions;
    ImageButton LabReports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_medikinesis);
        Details = (ImageButton)findViewById(R.id.your_details);
        Expenses = (ImageButton)findViewById(R.id.Expenses);
        Prescriptions =(ImageButton)findViewById(R.id.Prescriptions);
        LabReports = (ImageButton)findViewById(R.id.lab_tests);

        LabReports.setOnClickListener(this);
        Expenses.setOnClickListener(this);
        Prescriptions.setOnClickListener(this);
        Details.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==Details){
            Intent i = new Intent(YourMedikinesis.this, YourDetails.class);
            startActivity(i);
        }else if(v.getId()!=R.id.lab_tests){
            Intent i = new Intent(YourMedikinesis.this, YourInfos.class);
            i.putExtra("type", v.getId());
            startActivity(i);
        }
        if(v==LabReports){
            Intent i = new Intent(this, Hospitals.class);
            startActivity(i);
        }
    }
}
