package com.mohithulse.medikinesis;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import io.mdk.net.client.Client;
import io.mdk.net.utils.Report;
import io.mdk.secure.ErrorWindow;
import io.mdk.secure.MDKSecure;
import io.mdk.secure.NoteLocker;

import static android.content.ContentValues.TAG;

public class BackgroundTasks {

    static final String TAG = BackgroundTasks.class.getSimpleName();

    public static class ClientInit extends AsyncTask<Void, Void, Void>{
        Globals g = Globals.getInstance();


        @Override
        protected Void doInBackground(Void[] params) {
            g.setClient(new Client(g.getServer(), new Client.ExHandler() {
                @Override
                public void handle(Exception e) {
                    //Log.d(TAG, "handle:"+e.getLocalizedMessage());
                    new ErrorDialogView(e).execute();
                    Log.e(TAG, "handle:", e);
                }
            }));
            return null;
        }
    }
    public static class ClientClose extends AsyncTask<Void, Void, Void>{
        Globals g = Globals.getInstance();
        @Override
        protected Void doInBackground(Void[] args) {
            g.getClient().shutdown = true;
            g.getClient().cleanup();
            return null;
        }
    }
    public static class ClientReport extends AsyncTask{
        Globals g = Globals.getInstance();
        byte[][] Images;
        String Description;
        String[] Symptoms;
        boolean Gender;
        int Age;

        View view;
        public ClientReport(byte[][] images, String[] symptoms, String description, boolean gender, int age, View view) {
            Images = images;
            Symptoms = symptoms;
            Description = description;
            Gender = gender;
            Age = age;
            this.view =view;
        }

        @Override
        protected Object doInBackground(Object[] params) {
            if(!g.getClient().checkUser(g.getName())){
                Log.d(TAG, "doInBackground: about to report");
                Report report = new Report(Images,Gender,Symptoms,Age,Description);
                report.protect(MDKSecure.Hash.hash_str(MDKSecure.getInstance().getDevice_ID()), MDKSecure.Hash.hash_str(MDKSecure.getInstance().getSpecial_ID()));
                g.getClient().report(report, g.getName());
                Log.d(TAG, "doInBackground:reported");
                Snackbar.make(view,"Sending...", Snackbar.LENGTH_LONG).show();
            }else{
                Snackbar.make(view,"Name Taken", Snackbar.LENGTH_LONG).show();
            }
            return null;
        }
    }

    public static class ClientReportList extends AsyncTask{
        Globals g = Globals.getInstance();

        ListView list;
        Context context;
        public ClientReportList(Context context, ListView list) {
           this.context =context;
            this.list =list;
        }

        @Override
        protected Object doInBackground(Object[] params) {
            Log.d(TAG, "doInBackground: starting list getter");
            g.setList(g.getClient().listReports(g.getPin()));
            Log.d(TAG, "doInBackground: finished list getter");


            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1 ,g.getList()){
                @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view =super.getView(position, convertView, parent);

                TextView textView=(TextView) view.findViewById(android.R.id.text1);

            /*YOUR CHOICE OF COLOR*/
                textView.setTextColor(Color.BLUE);

                return view;
            }
        };
            list.setAdapter(stringArrayAdapter);

        }
    }

    public static class ClientReportView extends AsyncTask<Void, Void, Void>{
        Globals g = Globals.getInstance();
        String User;
        public Report report;
        ImageView img1;
        ImageView img2;

        public ClientReportView(TextView synopsis, TextView namenagengender, TextView symptoms, ImageView img2, ImageView img1, String user) {
            this.synopsis = synopsis;
            this.namenagengender = namenagengender;
            this.symptoms = symptoms;
            this.img2 = img2;
            this.img1 = img1;
            User = user;
        }

        TextView symptoms;
        TextView namenagengender;
        TextView synopsis;
        boolean noted;




        @Override
        protected Void doInBackground(Void[] params) {
           report = g.getClient().view(User, g.getPin());
            g.getClient().write("chknts "+ User);
            noted = Boolean.parseBoolean(g.getClient().read());
            g.setNoted(noted);
            return null;
        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);

            Bitmap bitmap = BitmapFactory.decodeByteArray(report.getDetected(), 0, report.getDetected().length);
            img1.setImageBitmap(bitmap);

            //img2

            Bitmap bitmap2 = BitmapFactory.decodeByteArray(report.getImgs()[1], 0,report.getImgs()[1].length);
            img2.setImageBitmap(bitmap2);

            //agengender
            String gender = "Female";
            if(report.gender){
                gender = "Male";
            }
            namenagengender.setText("Name: "+User+System.lineSeparator()+"Age: "+report.age +System.lineSeparator()+ "Gender: "+gender  );
            StringBuilder sb = new StringBuilder();
            for(String str :report.getTruesymptoms()){
                sb.append(str);
                sb.append(System.lineSeparator());
            }
            symptoms.setText(sb.toString());
            synopsis.setText(report.synopsis);
            if(noted){
                Snackbar.make(synopsis,"This report has already been answered!", Snackbar.LENGTH_INDEFINITE).show();
            }

            // Debug
//            if(MDKSecure.Hash.cmp(MDKSecure.getInstance().getDevice_ID(), report.dev_id_hash)){
//                Log.d(TAG, "onPostExecute: This is your report!");
//            }


        }
    }
    public static class ClientReportNote extends AsyncTask{
        Globals g = Globals.getInstance();
        String user;
        String note;

        public ClientReportNote(String note, String user, Report report) {
            this.note = NoteLocker.lock(note, report.dev_id_hash, report.spec_id_hash);
            this.user = user;
        }

        @Override
        protected Object doInBackground(Object[] params) {
            g.getClient().note(user,g.getPin(),note);
            return null;
        }
    }
    public static class ClientNoteView extends AsyncTask{
        Globals g = Globals.getInstance();
        String User;
        public String report;
        TextView t1;

        public ClientNoteView(String user, TextView t1) {
            User = user;
            this.t1 = t1;
        }

        @Override
        protected Object doInBackground(Object[] params) {
            report = NoteLocker.unlock(g.getClient().gnote(User));
            return null;
        }
        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N) {
                t1.setText(Html.fromHtml(report, Html.FROM_HTML_MODE_COMPACT));
            }else{
                t1.setText(Html.fromHtml(report));

            }
        }
    }

    public static class ErrorDialogView extends AsyncTask<Void, Void, Void> {

        AlertDialog dialog;
        AlertDialog.Builder builder;
        final Exception ex;

        public ErrorDialogView(Exception ex) {
            this.ex = ex;
        }

        @Override
        protected Void doInBackground(Void... params) {
            builder = ErrorWindow.showError(ex.getLocalizedMessage(), ex, Home.context);
            return null;
        }

        @Override
        protected void onPostExecute(Void imp) {
            super.onPostExecute(imp);
            builder.setNeutralButton(R.string.err_pop_endtxt, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    System.exit(1);
                }
            });
            dialog = builder.create();
            dialog.show();
        }
    }


}
